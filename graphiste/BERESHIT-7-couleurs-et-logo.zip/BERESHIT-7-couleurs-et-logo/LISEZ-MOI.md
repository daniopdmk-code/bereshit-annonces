# BERESHIT 7 — couleurs et logo

Pour le graphiste des affiches principales. *For the designer of the main posters.*

📄 **Commencer par `BERESHIT-7-fiche-couleurs-et-logo.pdf`** — deux pages : la palette avec ses valeurs, le logo et ses règles.
*Start with the two-page PDF.*

| Dossier | Contenu |
| --- | --- |
| `01-LOGO/SVG` | Le logo en **vectoriel** — à utiliser pour toute impression. *Vector — use for print.* |
| `01-LOGO/PNG` | Le même, fond transparent, 4096 px (logotype) / 2048 px (flamme). *Transparent PNG for screen.* |
| `02-COULEURS` | `BERESHIT-7-palette.ase` (à importer dans Photoshop / Illustrator / InDesign) et `BERESHIT-7-couleurs.txt` (HEX, RGB, CMJN). |
| `03-POLICES` | Exo 2 (titres, dates : graisse 800, capitales espacées) et Montserrat (pied, texte courant). Licence libre SIL OFL. |
| `04-REFERENCES` | Les planches d'identité d'origine (nuancier, logotype, flamme, trame, visuel maître, affiche 2026) et la charte complète en PDF. |

## Les couleurs

| | HEX | Rôle |
| --- | --- | --- |
| Jet Black | `#0C0C0C` | le fond |
| Graphite | `#1A1A1A` | fond secondaire, le mot sur fond clair |
| Crimson Red | `#ED3237` | la flamme, le « 7 », les filets — **jamais un texte courant** |
| Deep Blood Red | `#C41217` | lueurs, profondeur du rouge |
| Frost White | `#F5F6F1` | le mot et les titres sur fond sombre |

Les valeurs CMJN sont **indicatives** : l'imprimeur confirme avec son profil. Grand aplat noir : noir riche C60 M40 J40 N100.

## Les fichiers du logo

- `logotype-blanc` : lettres Frost White, flamme Crimson — **sur fond sombre**
- `logotype-noir` : lettres Graphite, flamme Crimson — sur fond clair
- `logotype-mono-blanc` : tout blanc — sur photo, filigrane
- `flamme` / `flamme-blanche` : la flamme seule

**Ne pas** déformer, recolorer la flamme, ajouter ombre, contour, biseau ou dégradé. Laisser autour **au moins la hauteur de la flamme**.

## À savoir

- Le logo a été **retracé en vectoriel** à partir des planches (il n'existait qu'en image). La signature « Igniting Men and Women Who Shake Cities » et le monogramme « mfc » de l'église **ne sont pas dans ce dossier**.
- L'imagerie de la marque : nuit, brouillard, silhouettes, une seule lueur rouge. Jamais de ciel bleu ni de lumière franche.
